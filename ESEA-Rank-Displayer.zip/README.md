ESEA Rank Displayer

Small chrome extension that displays ranks for an ESEA match in the post match stats page

<img src="http://i.imgur.com/OGNS8Sv.png">
